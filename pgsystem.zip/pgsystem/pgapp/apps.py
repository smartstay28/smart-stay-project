from django.apps import AppConfig


class PgappConfig(AppConfig):
    name = "pgapp"
